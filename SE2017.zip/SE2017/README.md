# SE2017
Smart Attendance Management System - SE2017
