###################################################
# students/apps.py:
#__author__ = ""
#__copyright__ = "Copyright 2017, SE2017 Course"
#__Team__ = ["Sri Harsha Gajavalli", "Koushik Bharadwaj", "David Christie", "Likhith Lanka", "Sajas P", "Rajeev Reddy"]
#__license__ = "MIT"
#__version__ = "1.2"
#__maintainer__ = "Likhith Lanka"
#__email__ = "likhith.l15@iiits.in"
#__status__ = "Development"
####################################################


# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class StudentsConfig(AppConfig):
    name = 'students'
